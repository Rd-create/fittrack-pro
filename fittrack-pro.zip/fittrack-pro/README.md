The objective of the project is to develop a modern, visually engaging fitness tracking dashboard that uses static data and 
entirely client-side logic. FitTrack Pro simulates goal tracking, activity logging, meal planning, 
and insights generation—using only HTML, CSS, and JavaScript.